make : compiler all source codes
make clean : clean all object and executable files

if you want to parse Cminus code,
type ./20151607 [source file name]
then Program Parse this code and print the syntax tree.
