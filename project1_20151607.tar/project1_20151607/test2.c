/* comment /* asdf *****/

/* com **

   /


   ment*/

/*commerrorb /*
