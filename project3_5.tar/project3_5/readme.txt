make : compiler all source codes
make clean : clean all object and executable files

if you want to parse Cminus code,
type ./project3_5 [source file name]
then Program Parse this code and analyze syntax tree.
if success, print the symbol table.
